### Hexlet tests and linter status:
[![Actions Status](https://github.com/demon2507/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/demon2507/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/999d4586775df51eb718/maintainability)](https://codeclimate.com/github/demon2507/python-project-49/maintainability)
